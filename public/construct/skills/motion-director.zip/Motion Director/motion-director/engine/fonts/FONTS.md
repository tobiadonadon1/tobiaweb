# Bundled fonts

All fonts here are licensed under the SIL Open Font License 1.1 (OFL). The OFL allows bundling, embedding and redistribution with software, but not selling the fonts on their own. The license text for each family is in the matching `*-OFL.txt` file. Instrument Serif is covered by the same OFL 1.1 terms as Instrument Sans (Copyright 2022 The Instrument Serif Project Authors).

| Family | Files | Use |
|---|---|---|
| Bricolage Grotesque | Regular, Bold | modern grotesque, the default |
| Instrument Serif | Regular, Italic | elegant editorial serif |
| Instrument Sans | Regular, Bold | clean UI sans |
| Outfit | Regular, Bold | geometric sans for explainers |
| Big Shoulders | Regular, Bold | condensed display, trailers |
| Boldonse | Regular | ultra-heavy display, slams |
| Gloock | Regular | display serif, cinematic |
| Geist Mono | Regular, Bold | numbers, labels, code |
| Tektur | Medium | techno display, neon |
| Nothing You Could Do | Regular | handwriting |
