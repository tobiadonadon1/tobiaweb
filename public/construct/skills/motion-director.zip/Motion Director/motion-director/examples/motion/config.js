// Film settings. The engine reads these before anything else.
window.FILM_CONFIG = {
  "title": "How Motion Director works",
  "style": "motion",
  "format": "landscape",
  "w": 1920,
  "h": 1080,
  "fps": 30,
  "seconds": 15,
  "bpm": 112,
  "bg": "#f2eee6",
  "grain": 0,
  "vignette": 0,
  "twos": false,
  "font": "Outfit"
};
