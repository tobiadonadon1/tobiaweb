# How Motion Director works — brief

**Format:** 16:9 landscape · 15 s · 112 BPM (7 bars exactly, BAR = 2.143 s, BEAT = 0.536 s) · Motion-graphics explainer · clean & bright minimal beat.

**Logline:** One continuous camera journey through the pipeline — terminal → two question cards → code → a finished MP4 dropped on the Desktop — and the file turns out to be the video you're watching.

**Twist (meta / match cut):** the prompt typed at the start is literally "/motion-director explain"; the MP4 that lands is "explain-motion-director.mp4", annotated in handwriting "you're watching it", and the camera pushes *through its thumbnail* into the end card. The film is its own proof.

**Hook (0–0.5 s):** a giant close-up of the prompt, "> /motion-director" with an orange caret, typing live (the camera tracks the caret); bell motif + soft hit on frame 0. On beat 1 the camera pulls back (camFit) to reveal the terminal and "Type an idea."

**Beat sheet (beats):**
- 0–6: 01 Type an idea. Close-up typing, pull-back on beats 1–3, Enter on beat 4 (with the kick).
- 6–12: whip-pan → 02 Answer two rounds. Card "1 Where will it be posted?" → cursor clicks 16:9 (beat 8). Card "2 Pick a look." → clicks Motion (beat 10).
- 12–16: whip-pan → 03 Written as code. Code streams in a dark editor, a clock pill counts 00:00 → 07:12 (time-lapse), chips "stock footage" / "editing app" struck out (13.5, 14). Riser + low-pass close. Beat 15: the editor folds into a glowing orange tile. Then true silence (A.silence) while the tile falls; the camera drops with it.
- 16 (8.57 s, 57%): DROP — impact, the tile blooms into the MP4 on a Desktop. 04 MP4 on your Desktop. Full minimal groove.
- 17: pill "original soundtrack" with live waveform. 18.5: handwritten "you're watching it" + arrow.
- 20.25–22: SIGNATURE — camFit pushes through the MP4 thumbnail, accelerating so it fills the frame exactly on the hit at beat 22, where it becomes the end card.
- 22–28: End card: "Motion Director." / "Idea in. Film out." / "> /motion-director" pill with blinking caret (echoes the hook → loops).

**Signature move:** zoom-through the MP4 thumbnail into the end card (thumbnail = end card poster, pixel-matched).
**Palette:** paper #f2eee6 · ink #15151b · accent #ff5a1f · card #ffffff · line #e2dbcf (code syntax tints only inside the dark editor).
**Type:** Outfit 700 headlines (tracking −0.03), Instrument Sans labels, Geist Mono terminal/code/numbers, Nothing You Could Do for the one annotation.
**Camera:** pull-back from the prompt, horizontal whip-pans on the beat, one vertical drop for the climax, one push-through (motionBlur only while the camera is fast). Parallax dot grid behind.
**Legibility:** headlines ~118 U; every secondary word that carries meaning is ≥ 44 U (window title, prompt, chips, clock, filename, pill, note, CTA); code, path and desktop labels are texture.

**Sound:** G major, Gmaj7–Em7–Cmaj7–D. Bell motif D5 G5 B5 A5 (unresolved) in the hook, resolved to G on the end card. Intro: soft keys + light kick. Sync: every keystroke, Enter click, card pops (rising pitch), cursor clicks, strike swipes, code typing texture, riser into 15.5, silence, falling downer, impact + crash on 16, pop on the pill, pencil scribble on the note, whoosh into the push, hit + bell on 22, typing + blip on the CTA, Gmaj9 ring-out.

**Words:** "Type an idea." · "Answer two rounds." · "Written as code." · "On your Desktop." · "explain-motion-director.mp4" · "original soundtrack" · "you're watching it" · "Motion Director." · "Idea in. Film out." · "/motion-director"
