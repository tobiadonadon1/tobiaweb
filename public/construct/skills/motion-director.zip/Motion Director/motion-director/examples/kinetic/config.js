// Film settings. The engine reads these before anything else.
window.FILM_CONFIG = {
  "title": "The 98¢ Trade",
  "style": "kinetic",
  "format": "vertical",
  "w": 1080,
  "h": 1920,
  "fps": 30,
  "seconds": 15,
  "bpm": 128,
  "bg": "#0b0c0b",
  "grain": 0.06,
  "vignette": 0,
  "twos": false,
  "font": "Bricolage Grotesque"
};
