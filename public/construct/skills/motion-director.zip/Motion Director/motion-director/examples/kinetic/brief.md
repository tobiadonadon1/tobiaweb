# The 98¢ Trade — brief

**Format:** vertical 1080×1920 · 15 s · 30 fps · 128 BPM (8 bars, BAR = 1.875 s) · kinetic typography · punchy electronic.

**Logline:** A €5 Claude Code bot that paper-trades Polymarket's near-certain favorites — sold by one number that literally becomes the picture.

**Twist:** "Near-certain" is only half the story — the fine print is where favorites trip. Jev is shown as a reading beam that scans a market's rules and flags the catch. Then the evidence: 8,318 past trades count up as 8,318 real dots, and on the drop they fuse into one lime slab — with ~1% left dark (99% paid out, honestly shown).

**Hook (0.0–0.5 s):** "98¢" is already mid-slam on frame 0 in acid lime, impact + kick + first motif note.

**Beat sheet**
| Bar | Time | Picture | Sound |
|---|---|---|---|
| 1 | 0.00 | HOOK "98¢" slam · POLYMARKET · "Near-certain / favorites." (beat 1) · 0–100¢ price line, marker races to the 97–99.5¢ zone (beat 2) | impact, motif A4-C5-E5-D5 on pluck, swipe, chirp |
| 2–3 | 1.875 | RULES: deck of rule cards; Jev beam reads 14 lines (tick per line); stack "JEV READS / THE FINE PRINT / FIRST." — "FIRST." slams on bar 3 exactly as the beam flags the postponement clause | whoosh, hits on beats, ticks, impact+clap+chirp |
| 4 | 5.625 | BUILD: "8,318" counts up (eOutExpo) while 8,318 dots pour in as a diagonal wave; lands on beat 4; 0.25 s freeze | riser, snare roll, decelerating ticks, hit, **silence** |
| 5 | 7.500 | DROP (signature): flash; dots go lime and ripple-fuse into one solid slab, ~83 stay dark; "99%" slams, "paid out." | impact+boom+crash, four-on-the-floor, pumping bass, sparkle |
| 6 | 9.375 | Dark wipe up; "+0.58%" counts in lime, rule line; "per trade, / on average." | whoosh, blips, bell on landing |
| 7 | 11.25 | "~10 MIN SETUP"; Claude Code card: "› hi" typed; "Open the folder. / Type hi." | thinner drums, two key clicks, enter, blips |
| 8 | 13.125 | END: same "98¢" at the same place as frame 0 (match cut) → "The / 98¢ / Trade", "€5 bot for Claude Code", "Paper trading · Not financial advice"; still from 14.0 s | impact, motif answered A4-C5-E5-A5 on bells, Am(add9) tail |

**Signature move:** number → image. The 8,318 counter fills 8,318 dots; on the drop they fuse into a solid lime slab (99%), leaving the ~1% visibly dark.

**Palette:** bg #0b0c0b · fg #f3f0e7 · accent (acid lime) #b8ff3b · card #151816 · dim #8d928c.
**Type:** Boldonse (slams: 98¢, FIRST., 8,318, 99%, +0.58%, Trade) · Bricolage Grotesque 700 (lines) · Geist Mono (labels, fine print).
**Camera:** cut on the downbeat with a push-through zoom (pre-cut eInExpo push, post-cut settle), slow per-scene push-in drift, shake on hits, frozen before the drop, dead still end card.

**Sound identity:** punchy electronic, 128 BPM, A minor, Am–F–C–G intro / Am–F–G → Am drop and end. Sync points: 0.00 impact · 1.875 whoosh/hits · 3.75 impact (FIRST.) · 7.03 count lands · 7.25 silence · 7.50 drop · 9.2 whoosh · 11.7/11.95 key clicks · 13.125 end impact + bells.

**Exact words:** POLYMARKET · 98¢ · Near-certain / favorites. · 0¢ · 97–99.5¢ · 100¢ · JEV · AI BY TYPESAFE · MARKET RULES · JEV READS / THE FINE PRINT / FIRST. · 8,318 · PAST TRADES TESTED · 99% · paid out. · BACKTEST · +0.58% · per trade, / on average. · ~10 MIN SETUP · Claude Code · › hi · Open the folder. / Type hi. · The / 98¢ / Trade · €5 bot for Claude Code · Paper trading · Not financial advice

**Accuracy guardrails:** only the customer's facts; no profit promise (numbers are labelled as past/backtest; ~1% of dots visibly not paid); "Not financial advice" on the end card; name exactly "The 98¢ Trade"; price €5. The rules text in the card is generic, original illustration.
