// Film settings. The engine reads these before anything else.
window.FILM_CONFIG = {
  "title": "Nightshift",
  "style": "neon",
  "format": "vertical",
  "w": 1080,
  "h": 1920,
  "fps": 30,
  "seconds": 15,
  "bpm": 96,
  "bg": "#04040a",
  "grain": 0.08,
  "vignette": 0.5,
  "twos": false,
  "font": "Big Shoulders"
};
