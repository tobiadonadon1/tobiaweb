# NIGHTSHIFT — teaser brief

**Format:** vertical 9:16 · 15 s · 96 BPM (6 bars, BAR 2.5 s, BEAT 0.625 s) · neon / cinematic · D minor → D major

**Logline:** At midnight you log off and the screen dies to a single pixel. The pixel refuses to go dark: it becomes a cursor and codes all night, until 07:00 bursts into NIGHTSHIFT.

**Twist:** reversal + personify. "The pixel that stays awake." The CRT power-off that should end the day leaves one living dot behind, and that dot is the product.

**Hook (0–0.5 s):** a glowing editor mid-flow (code scrolling, keys clattering), "YOU LOG OFF." slamming in word by word, each word on an 8th note with a low hit and a bell (D–F–A).

**Beat sheet**
| t (s) | beat | picture | sound |
|---|---|---|---|
| 0.00 | 0 | editor + YOU / LOG / OFF. slams | hit + bell D5/F5/A5, typing clatter, sub |
| 2.19 | 3.5 | CRT power-off: squash to a line, shrink to one dot | relay click, CRT whine down, music muffles |
| 2.50 | 4 | the dot's heartbeat (lub-dub) | double kick |
| 3.13 | 5 | IT DOESN'T. · dot morphs into a block cursor | hit + bell D6, Dm9 pad starts filtered |
| 3.50 | 5.6 | cursor glides to the editor | swipe |
| 3.75 | 6 | types `while (you.asleep) {` | a key sound per character |
| 5.00 | 8 | clock 00:00 appears; `fix(bugs);` | hit + blip; heartbeat |
| 5.63–6.88 | 9–11 | `write(tests);` `ship();` `}` one per beat | keys |
| 5.00–8.44 | 8–13.5 | clock races to 06:59, log of commits streams faster and faster, slow camera push | riser, rising blip per hour, accelerating kicks, key buzz |
| 8.44 | 13.5 | FREEZE: 06:59 · 47 COMMITS · "ready for review ▮" | total silence |
| 8.75 | 14 | DROP: light floods out of the cursor → NIGHT slams, sparks, shake, dawn horizon | boom + impact + crash, trailer pulse on D |
| 9.38 | 15 | SHIFT ignites like a neon tube (flicker) | impact + electric buzz |
| 11.25 | 18 | cursor types SHIPS MONDAY | keys, Bbmaj7 |
| 12.50 | 20 | dawn warms, end card holds; still from 14.4 | Dadd9 + bell motif resolved D–F#–A–D |

**Signature move:** the CRT collapse to one pixel that stays alive, becomes the cursor, and at the drop floods the frame with light to reveal the title.

**Palette:** bg #04040a · ink #eaf3ff · accent cyan #27e4ff · support violet #8b6bff · dawn #ff4fa8 (only after 07:00)
**Type:** Big Shoulders 700 (headlines, title) + Geist Mono (code, clock, tagline)
**Camera:** slow push through the night (1 → 1.07), dead freeze, shake on the drop, near-still end card.
**Words:** YOU LOG OFF. · IT DOESN'T. · (code) · 06:59 · 47 COMMITS · NIGHT / SHIFT · SHIPS MONDAY
