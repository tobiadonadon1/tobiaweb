// Film settings. The engine reads these before anything else.
window.FILM_CONFIG = {
  "title": "Cup Five Says Nope",
  "style": "ink",
  "format": "square",
  "w": 1080,
  "h": 1080,
  "fps": 24,
  "seconds": 15,
  "bpm": 112,
  "bg": "#ebe3d2",
  "grain": 0.3,
  "vignette": 0.14,
  "twos": true,
  "font": "Instrument Serif"
};
