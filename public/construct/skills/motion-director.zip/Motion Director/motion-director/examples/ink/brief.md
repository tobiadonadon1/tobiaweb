# Cup Five Says Nope — brief

**Logline:** An assembly line of coffee cups gets filled one per beat, each more wired than the last; cup #5 dodges the pot twice, then backflips and lands upside down: closed.
**Twist:** Pattern break + personify. Four cups obey the rhythm; the fifth breaks it, and the upside-down cup (the universal "no more") is the punchline.
**Hook (0–0.5 s):** Mid-action. Pot already pouring into cup #1, hand-lettered "#1" top-left, next cup waiting at the edge; glug + warm keys on frame 0.
**Signature move:** The twisting backflip: cup launches in silence, spins 1.5 turns, lands upside down on the downbeat (impact, dust, shake).

## Beat sheet (112 BPM, 7 bars = 15.0 s, BAR 2.143 s)
- Bar 1 (0–2.14): conveyor. Cups #1–#4 step in on each beat, get filled; faces escalate happy → grin → wired → fried. Counter pops 1-2-3-4.
- Bar 2 (2.14–4.29): #5 arrives. Pot leans in ("!"). Pour starts on beat 3 → cup hops left, coffee splashes on the table. Side-eye.
- Bar 3 (4.29–6.43): pot chases left, pours, cup hops right (raspberry). Pot fumes, chases right.
- Bar 4 (6.43–8.57): build. Camera creeps in, cup crouches, determined; pot trembles; riser. Silence 7.9. Launch 8.04 (backflip in silence, pour misses).
- Bar 5 (8.57): DROP. Lands upside down. Impact. "#5" scribbled out on beat 2, pot deflates (sad trombone), floats away.
- Bar 6 (10.71): "NOPE." writes itself on, bell motif descends; accent underline.
- Bar 7 (12.86–15): last drip plinks on the upturned cup; one eye peeks, back to smug. Still.

## Look
Ink style, square. Paper #ebe3d2, ink #2e1a1b, cream cups #f8f1e2 with terracotta band #d2725a (accent), mustard enamel pot #d9a528, coffee #5a3220, wood table #c8996a.
Type: hand-lettering only ("#1".."#5", "!", "NOPE."). Camera: locked-off, one slow push-in on the build, snap back on the launch, shake on the landing.

## Sound
Warm and playful, 112 BPM, F major, F–C–Dm–Bb. Keys on 1 & 3, soft kick, quiet shaker; pluck motif F-A-C-E ascending (one note per filled cup), resolved descending E-C-A-F on "NOPE.".
Sync: glug per pour, counter pops (rising pitch), "!" chirp, hop chirps + landing ticks, table splashes, pot swipes, raspberry, steam hiss, riser → silence → launch whoosh → splash in silence → IMPACT + crash on 8.571, scratch on the scribble, sad trombone, downer on exit, bells on NOPE, final plink + tonic chord ringing out.
